package com.chochoromaluco.game;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import java.util.*;

public class GameView extends View {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    Bitmap dog;
    Random rnd = new Random();
    ArrayList<Item> items = new ArrayList<>();
    int screen=0, score=0, lives=3, level=1;
    float px=0, py=0, speed=7, spawn=0;
    boolean paused=false;
    boolean up,down,left,right;

    class Item { float x,y; boolean good; Item(float a,float b,boolean g){x=a;y=b;good=g;} }

    public GameView(Context c) {
        super(c);
        dog = BitmapFactory.decodeResource(getResources(), R.drawable.chochoro);
        setFocusable(true);
    }

    protected void onDraw(Canvas c) {
        super.onDraw(c);
        if(screen==0) drawMenu(c); else drawGame(c);
        if(screen==2) drawEnd(c);
        if(screen==1) { postInvalidateDelayed(16); update(); }
    }

    void bg(Canvas c, int color) { c.drawColor(color); }

    void drawMenu(Canvas c) {
        bg(c, Color.rgb(135,206,235));
        p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(58); p.setColor(Color.rgb(255,107,53));
        c.drawText("🐶 CHOCHORO MALUCO!", getWidth()/2f, 90, p);
        RectF d=new RectF(getWidth()/2f-120,120,getWidth()/2f+120,360);
        c.drawBitmap(dog,null,d,p);
        p.setTextSize(22); p.setColor(Color.DKGRAY);
        c.drawText("Pegue os ossinhos e fuja das sujeiras!",getWidth()/2f,395,p);
        button(c,getWidth()/2f-130,440,getWidth()/2f+130,510,"▶ JOGAR",Color.rgb(255,107,53));
        p.setTextSize(15); p.setColor(Color.DKGRAY);
        c.drawText("Use as setas, WASD ou os botões na tela.",getWidth()/2f,550,p);
    }

    void drawGame(Canvas c) {
        bg(c,Color.rgb(135,206,235));
        p.setColor(Color.rgb(123,211,91)); c.drawRect(0,getHeight()*0.58f,getWidth(),getHeight(),p);
        p.setTextAlign(Paint.Align.LEFT); p.setTextSize(22); p.setColor(Color.DKGRAY);
        c.drawText("⭐ Pontos: "+score,20,35,p);
        c.drawText("❤️ Vidas: "+lives,190,35,p);
        c.drawText("🏆 Fase: "+level,350,35,p);

        RectF d=new RectF(px,py,px+95,py+95); c.drawBitmap(dog,null,d,p);

        p.setTextAlign(Paint.Align.CENTER);
        for(Item it:items) {
            p.setTextSize(42); p.setColor(Color.WHITE);
            c.drawText(it.good ? "🦴" : "💩",it.x,it.y,p);
        }

        // Touch-friendly controls
        button(c,25,getHeight()-100,95,getHeight()-35,"⬅",Color.WHITE);
        button(c,105,getHeight()-100,175,getHeight()-35,"➡",Color.WHITE);
        button(c,getWidth()-175,getHeight()-100,getWidth()-105,getHeight()-35,"⬆",Color.WHITE);
        button(c,getWidth()-95,getHeight()-100,getWidth()-25,getHeight()-35,"⬇",Color.WHITE);
        button(c,getWidth()-90,8,getWidth()-15,48,paused?"▶":"⏸",Color.rgb(247,220,111));
    }

    void drawEnd(Canvas c) {
        p.setColor(0x99000000); c.drawRect(0,0,getWidth(),getHeight(),p);
        p.setTextAlign(Paint.Align.CENTER); p.setTextSize(42); p.setColor(Color.WHITE);
        c.drawText("😵 O CHOCHORO CANSOU!",getWidth()/2f,180,p);
        p.setTextSize(24); c.drawText("Pontuação: "+score,getWidth()/2f,230,p);
        button(c,getWidth()/2f-150,280,getWidth()/2f+150,345,"🔄 JOGAR NOVAMENTE",Color.rgb(255,107,53));
    }

    void button(Canvas c,float l,float t,float r,float b,String text,int color) {
        p.setColor(color); c.drawRoundRect(new RectF(l,t,r,b),16,16,p);
        p.setTextAlign(Paint.Align.CENTER); p.setTextSize(20); p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setColor(color==Color.WHITE?Color.DKGRAY:Color.WHITE);
        c.drawText(text,(l+r)/2,(t+b)/2+7,p);
    }

    void start() {
        screen=1; score=0; lives=3; level=1; items.clear();
        px=getWidth()/2f-45; py=getHeight()/2f-45; paused=false; spawn=0;
        invalidate();
    }

    void update() {
        if(paused) return;
        if(up) py-=speed; if(down) py+=speed; if(left) px-=speed; if(right) px+=speed;
        px=Math.max(0,Math.min(getWidth()-95,px));
        py=Math.max(55,Math.min(getHeight()-120,py));
        spawn++;
        if(spawn>Math.max(25,70-level*6)) {
            items.add(new Item(40+rnd.nextFloat()*(getWidth()-80),
                    100+rnd.nextFloat()*(getHeight()-210), rnd.nextFloat()>.25));
            spawn=0;
        }
        Iterator<Item> it=items.iterator();
        while(it.hasNext()) {
            Item a=it.next();
            if(Math.abs((px+48)-a.x)<65 && Math.abs((py+48)-a.y)<65) {
                if(a.good) { score+=10; if(score%100==0) level++; }
                else { lives--; if(lives<=0){screen=2;} }
                it.remove();
            }
        }
    }

    public boolean onTouchEvent(android.view.MotionEvent e) {
        if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE) {
            float x=e.getX(), y=e.getY();
            if(screen==0 && x>getWidth()/2-150 && x<getWidth()/2+150 && y>420 && y<530) { start(); return true; }
            if(screen==2) { start(); return true; }
            if(screen==1) {
                if(x>getWidth()-105 && y<65){paused=!paused; invalidate();return true;}
                up=down=left=right=false;
                if(y>getHeight()-120) {
                    if(x<100) left=true;
                    else if(x<190) right=true;
                    else if(x>getWidth()-190 && x<getWidth()-100) up=true;
                    else if(x>getWidth()-105) down=true;
                }
            }
        }
        if(e.getAction()==MotionEvent.ACTION_UP){up=down=left=right=false;}
        return true;
    }

    public boolean onKeyDown(int key, android.view.KeyEvent e) {
        if(key==19)up=true; if(key==20)down=true; if(key==21)left=true; if(key==22)right=true;
        if(key==W)up=true; if(key==S)down=true; if(key==A)left=true; if(key==D)right=true;
        return true;
    }
    public boolean onKeyUp(int key, android.view.KeyEvent e) {
        if(key==19)up=false; if(key==20)down=false; if(key==21)left=false; if(key==22)right=false;
        if(key==W)up=false; if(key==S)down=false; if(key==A)left=false; if(key==D)right=false;
        return true;
    }
    static final int W=51,S=47,A=29,D=32;
}
