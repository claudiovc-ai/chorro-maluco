# Chochoro Maluco — versão Java Android

Projeto Android Studio em Java, usando a imagem do Chochoro enviada.

Recursos:
- Menu e botão JOGAR
- Personagem Chochoro
- Ossinhos, obstáculos, pontos, vidas e fases
- Controles por toque e teclado
- Funciona sem servidor/API
- Estrutura pronta para depois receber login, ranking, moedas e API

Como abrir:
1. Instale o Android Studio.
2. Abra esta pasta como projeto.
3. Espere o Gradle sincronizar.
4. Execute em um celular/emulador Android.

Observação: este pacote contém o código-fonte Java e os recursos. O APK pode ser gerado pelo Android Studio em Build > Build APK(s).
